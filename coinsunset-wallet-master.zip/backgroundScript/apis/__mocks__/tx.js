export const getTxnEncodedLength = () => 144;
