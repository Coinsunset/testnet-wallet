import { TypeRegistry } from '@polkadot/types';

const registry = new TypeRegistry();

export default registry;
