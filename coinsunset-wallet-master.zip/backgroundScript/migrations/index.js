import { migration1to2 } from './002';

export { migration1to2 };
