export { default } from './terms.container';
