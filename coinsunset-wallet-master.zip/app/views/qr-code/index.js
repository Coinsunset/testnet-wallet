export { default } from './qr-code.container';
