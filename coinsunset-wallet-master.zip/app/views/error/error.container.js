import { connect } from 'react-redux';
import Error from './error.component';

export default connect()(Error);
