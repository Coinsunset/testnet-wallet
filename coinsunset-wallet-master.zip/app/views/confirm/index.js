export { default } from './confirm.container';
