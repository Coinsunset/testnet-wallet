export { default } from './import-wallet.container';
