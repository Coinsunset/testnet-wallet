export { default } from './dapp-requests.container';
