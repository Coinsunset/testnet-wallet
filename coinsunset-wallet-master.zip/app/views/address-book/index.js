export { default } from './address-book.container';
