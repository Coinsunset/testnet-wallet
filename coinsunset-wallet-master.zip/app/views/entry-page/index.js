export { default } from './entry-page.container';
