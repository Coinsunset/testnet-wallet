export const FAIL = '#F37565';
export const SUCCESS = '#4ED09B';
export const PENDING = '#F5A623';
