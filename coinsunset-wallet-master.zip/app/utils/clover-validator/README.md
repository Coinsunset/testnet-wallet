# Usage

This is a short guide on how to use the `CloverValidator` within a component.

### Steps:

- Import the `CloverValidator` class.

### Code Example:

```js
```
